import os
import zipfile
import openai
import time
import tempfile
import pandas as pd
from io import BytesIO
import streamlit as st
from pathlib import Path
from docx import Document

# Set your OpenAI API key here
deployment_name="gpt-35-turbo-16k"
openai.api_type = "azure"
openai.api_key = "9c1a8daa826c4abab74f38cff791f231" #os.getenv("AZURE_OPENAI_API_KEY")  # Alternatively, paste your key directly: "your_api_key"
openai.api_base = "https://myfirstopenaiplayground.openai.azure.com/"  # Replace with your Azure OpenAI endpoint
openai.api_version = "2024-06-01"  # Ensure the API version matches the one in your Azure Portal



# Function to extract zip files
def extract_zip(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

# Function to read and convert Excel content to code format
def read_excel(file_path):
    try:
        excel_data = pd.read_excel(file_path)
        return excel_data.to_string()
    except Exception as e:
        st.warning(f"Error reading Excel file: {e}")
        return None

# Read file content with encoding handling
def read_file(file_path, file_type):
    if file_type == 'xlsx':
        return read_excel(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding='ISO-8859-1') as file:
            return file.read()

# Convert code using OpenAI API
def get_code_from_openai(content, language):
    prompt = f"Convert the following code to {language} and provide only the code without any explanations and comments:\n\n{content}"
    try:
        messages = [
            {"role": "system", "content": f"You are an AI that generates {language} code."},
            {"role": "user", "content": prompt}
        ]
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            max_tokens=800,
            temperature=0.7
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        st.warning(f"Error with OpenAI API: {e}")
        return None

# Generate unit tests
def generate_unit_test(filecontent, language):
    try:
        prompt = f"Generate unit tests for the following {language} code. Provide only the code without any explanations:\n\n{filecontent}"
        messages = [
            {"role": "system", "content": f"You are an AI that generates {language} unit tests."},
            {"role": "user", "content": prompt}
        ]
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=messages,
            max_tokens=800,
            temperature=0.7
        )
        return response.choices[0].message['content'].strip()
    except Exception as e:
        st.warning(f"Error generating unit tests: {e}")
        return None

# Process files in zip and retrieve converted code
def process_files(zip_file, languages):
    with tempfile.TemporaryDirectory() as temp_dir:
        print(temp_dir)
        extract_zip(zip_file, temp_dir)
        converted_files = {}
        supported_extensions = ['sas', 'xlsx', 'csv', 'txt', 'py', 'js', 'cs', 'java']  # Add more if needed

        files = [f for f in os.listdir(temp_dir) if any(f.endswith(ext) for ext in supported_extensions)]
        print(files)
        # total_steps = len(files) * (2 if gene?rate_tests else 1)
        progress = st.progress(0)

        for i, file_name in enumerate(files):
            file_path = os.path.join(temp_dir, file_name)
            file_type = Path(file_name).suffix[1:]
            content = read_file(file_path, file_type)

            # Code conversion step
            if content:
                for i in languages:
                        
                    code = get_code_from_openai(content, i)
                    if code:
                        converted_files[file_name] = code
                        time.sleep(1)  # Delay for rate limits

        #     # Unit test generation step
        #     if generate_tests and code:
        #         unit_test_code = generate_unit_test(code, language)
        #         if unit_test_code:
        #             converted_files[file_name + "_test"] = unit_test_code
        #         progress.progress((i + 1) * 2 / total_steps)  # Update for unit test step

        #     # Update progress
        #     progress.progress((i + 1) / total_steps)

        # progress.empty()
        # return converted_files
    

# Process files in zip for document creation
def process_files_for_document(zip_file):
    with tempfile.TemporaryDirectory() as temp_dir:
        extract_zip(zip_file, temp_dir)
        all_content = []
        supported_extensions = ['sas', 'xlsx', 'csv', 'txt', 'py', 'js', 'cs', 'java']  # Add more if needed
        files = [f for f in os.listdir(temp_dir) if any(f.endswith(ext) for ext in supported_extensions)]

        for file_name in files:
            file_path = os.path.join(temp_dir, file_name)
            file_type = Path(file_name).suffix[1:]
            content = read_file_for_document(file_path, file_type)
            if content:
                all_content.append(content)

        return "\n\n".join(all_content)
# Function to read file content for document creation
def read_file_for_document(file_path, file_type):
    if file_type == 'xlsx':
        return read_excel(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding='ISO-8859-1') as file:
            return file.read()
def app():
    st.write('# Get Started with Code Converter')

    uploaded_file = st.file_uploader(label='Upload files with various code')
    languages = ['Python', 'C#', 'Java', 'JavaScript']
    selected_languages = st.multiselect("Choose the target language for conversions", languages)
    list_of_languages = []
    if selected_languages:
        st.write(f"You have selected: {', '.join(selected_languages)}")

        # Example action: Print a message or perform some logic based on selection
        if 'Python' in selected_languages:
            list_of_languages.append('Python')
        if 'C#' in selected_languages:
            list_of_languages.append('C#')

        if 'Java' in selected_languages:
            list_of_languages.append('Java')

        if 'JavaScript' in selected_languages:
            list_of_languages.append('JavaScript')
    else:
        st.write("Please select at least one language for conversion.")

    
    automation = ['Generate unit tests for the chosen language', 'Summarize automation', 'Create Documentation']
    selected_automations = st.multiselect("Choose the automation", automation)

    list_of_automations = []
    if selected_automations:
        st.write(f"You have selected: {', '.join(selected_automations)}")

        # Example action: Print a message or perform some logic based on selection
        if 'Generate unit tests for the chosen language' in selected_automations:
            list_of_automations.append('unit tests')
        if 'Summarize automation' in selected_automations:
            list_of_automations.append('Summarize automation')
        if 'Create Documentation' in selected_automations:
            list_of_automations.append('Java')

    if uploaded_file:
        with tempfile.NamedTemporaryFile(delete=False) as tmp_zip:
                    tmp_zip.write(uploaded_file.read())
                    zip_file_path = tmp_zip.name
                    
        if st.button('Generate Conversion'):
            converted_files = process_files(zip_file_path, list_of_languages)

            

            


            



